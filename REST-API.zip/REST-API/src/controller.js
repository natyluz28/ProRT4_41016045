import { pool } from './database.js';

class PersonaController {
    async getAll(req, res) {
        try {
            const [result] = await pool.query('SELECT * FROM personas');
            res.json(result);
        } catch (error) {
            console.error('Error fetching personas:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    async add(req, res) {
        try {
            const persona = req.body;
            const [result] = await pool.query(
                'INSERT INTO Personas (nombre, apellido, dni) VALUES (?, ?, ?)', 
                [persona.nombre, persona.apellido, persona.dni]
            );
            res.json({ "Id insertado": result.insertId });
        } catch (error) {
            console.error('Error inserting persona:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    async delete(req, res) {
        try {
            const persona = req.body;
            const [result] = await pool.query('DELETE FROM Personas WHERE id = ?', [persona.id]);
            res.json({ "Registros eliminados": result.affectedRows });
        } catch (error) {
            console.error('Error deleting persona:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }

    async update(req, res) {
        try {
            const persona = req.body;
            const [result] = await pool.query(
                'UPDATE Personas SET nombre = ?, apellido = ?, dni = ? WHERE id = ?',
                [persona.nombre, persona.apellido, persona.dni, persona.id]
            );
            res.json({ "Registro actualizado": result.changedRows });
        } catch (error) {
            console.error('Error updating persona:', error);
            res.status(500).json({ error: 'Internal Server Error' });
        }
    }
}

export const persona = new PersonaController();
