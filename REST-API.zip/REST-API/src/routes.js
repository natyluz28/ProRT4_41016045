import { Router } from 'express';
import { persona } from './controller.js';

const router = Router();


router.get('/personas', (req, res) => persona.getAll(req, res));
router.post('/personas', (req, res) => persona.add(req, res));
router.delete('/personas', (req, res) => persona.delete(req, res));
router.put('/personas', (req, res) => persona.update(req, res));

export { router };

